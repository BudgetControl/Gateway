<?php
declare(strict_types=1);

namespace Budgetcontrol\Gateway\Http\Controllers;

class TransferController extends EntryController {

    protected string $entryType = "/transfer";

}