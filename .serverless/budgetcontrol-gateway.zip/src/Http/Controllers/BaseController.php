<?php
namespace Budgetcontrol\Gateway\Http\Controllers;

class BaseController extends Controller
{
    
}